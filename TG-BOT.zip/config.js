import fs from "fs"

global.BOT_TOKEN = "8369267806:AAFMlQShMqZ6L3GC-Rqhr2fJy1nSY0LnNjA" 

global.PREFIX = "/"


global.owner = ["@fg_log"] //-usuario
global.ownerID = ["8356741852"]

//--info FG
global.botName = 'Senna'
global.fg_ig = 'https://instagram.com/fg.error' 
global.fg_sc = 'https://github.com/FG98F/dylux-bot' 
global.fg_pyp = 'https://paypal.me/fg98f'
global.fg_logo = 'https://i.ibb.co/1zdz2j3/logo.jpg' 

//--- Grupos WA
global.fg_canal = '@fg_canal'
global.fg_group = "@fg_userss"


console.log("⚙️ Config cargada")